﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stratis.Sidechains.Features.BlockReceiver
{
    internal class BlockReceiverManager : IBlockReceiverManager
    {
	    public BlockReceiverManager()
	    {
		    
	    }
    }
}
