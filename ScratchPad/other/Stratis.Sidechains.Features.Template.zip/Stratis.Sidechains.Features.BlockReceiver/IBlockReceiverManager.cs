﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stratis.Sidechains.Features.BlockReceiver
{
    internal interface IBlockReceiverManager
    {
    }
}
