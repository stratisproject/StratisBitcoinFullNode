﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Stratis.Bitcoin.Builder;
using Stratis.Bitcoin.Builder.Feature;

namespace Stratis.Sidechains.Features.BlockReceiver
{
	public class BlockReceiverFeature : FullNodeFeature
	{
		public BlockReceiverFeature()
		{
			
		}

		public override void Start()
		{
			//do nothing
		}
	}

	public static partial class IFullNodeBuilderExtensions
	{
		public static IFullNodeBuilder AddBlockGenerator(this IFullNodeBuilder fullNodeBuilder)
		{
			fullNodeBuilder.ConfigureFeature(features =>
			{
				features
					.AddFeature<BlockReceiverFeature>()
					.FeatureServices(services =>
					{
						services.AddSingleton<IBlockReceiverManager, BlockReceiverManager>();
					});
			});
			return fullNodeBuilder;
		}
	}
}
